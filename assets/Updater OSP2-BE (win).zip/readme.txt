Автоматическая загрузка последней версии OSP2-BE
Инструкция: 
1. Поместить файл Updater OSP2-BE Updater.bat в папку Quake 3
2. Запустить
3. Дождаться окончания загрузки
4. Нажать любую кнопку

Создано: 
Mus1n - для Windows

===================================================================================
Automatic download of the latest OSP2-BE version
How to use:

1. Place the OSP2-BE Updater.bat file into Quake 3 folder
2. Run it
3. Wait for the download to complete
4. Press any key

Made by:
Mus1n - for Windows