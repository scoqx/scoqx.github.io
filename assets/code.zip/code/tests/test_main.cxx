#include <catch2/catch_test_macros.hpp>
#

#define CONFIG_CATCH_MAIN

TEST_CASE("test stub", "[test stub]")
{
}
